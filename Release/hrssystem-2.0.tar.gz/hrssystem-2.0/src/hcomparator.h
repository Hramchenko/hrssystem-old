/***************************************************************************
 *   Copyright (C) 2007 by Hramchenko                                      *
 *   hramchenko@bk.ru                                                      *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 ***************************************************************************/
#ifndef HCOMPARATOR_H
#define HCOMPARATOR_H

/**
	@author Hramchenko <user@localhost.localdomain>
*/

#include <QtOpenGL>

class	HVoxel;
class	HFrame;

class HComparator{
	public:
		HComparator(QGLWidget* parent, int max_width, int max_height);
    virtual ~HComparator();
		char	compare(HVoxel* voxel, HFrame* frame);
	private:
		void	initPixelBuffer();
		void	createVoxelList();
		void	render();
		char	compareData(char* image, char* current_data, unsigned long int data_length);
		bool	findWindow(char* data_begin_abs, unsigned long int data_begin_offset,  unsigned long int data_length, unsigned long int& window_offset, unsigned long int& window_length);
		char	testWindow(char* data_begin, unsigned long int data_length);
	private:
		HVoxel*	currentVoxel;
		HFrame*	currentFrame;
		int	voxelList;
		char*	currentData;
		QGLPixelBuffer*	pixelBuffer;
};

#endif
