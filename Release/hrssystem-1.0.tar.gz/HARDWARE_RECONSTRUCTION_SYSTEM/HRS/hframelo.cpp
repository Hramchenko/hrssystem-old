/***************************************************************************
 *   Copyright (C) 2007 by Hramchenko                                      *
 *   hramchenko@bk.ru                                                      *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 ***************************************************************************/
#include "hframelo.h"

#include <iostream.h>

#include <GL/gl.h>
#include <GL/glu.h>

HFrameLO::HFrameLO(): HFrame(){
}

HFrameLO::~HFrameLO(){
}

void	HFrameLO::setGL(){
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	glViewport(0, 0, width, height);
	glOrtho(left, right, bottom, top, near, far);
	glMatrixMode(GL_MODELVIEW);
	gluLookAt(eyeX, eyeY, eyeZ, centerX, centerY, centerZ, upX, upY, upZ);
}

void	HFrameLO::consoleInput(){
	cout<<"������� ��������� ��� gluLookAt(eyeX, eyeY, eyeZ, centerX, centerY, centerZ, upX, upY, upZ)"<<endl;
	cin>>eyeX>>eyeY>>eyeZ>>centerX>>centerY>>centerZ>>upX>>upY>>upZ;
	cout<<"������� ��������� ��� glOrtho(left, right, bottom, top, near, far)"<<endl;
	cin>>left>>right>>bottom>>top>>near>>far;
}
