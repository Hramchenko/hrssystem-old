/***************************************************************************
 *   Copyright (C) 2007 by Hramchenko                                      *
 *   hramchenko@bk.ru                                                      *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 ***************************************************************************/

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include <iostream.h>
#include <string.h>
#include <math.h>

#include <signal.h>
#include <sys/types.h>
#include <unistd.h>

#include "hglwindow.h"
#include "hglwindowm.h"
#include "hglwindowi.h"

HGLWindow* window;	

void	sigsegv_handler(int a){
	cout<<"���������� ���������."<<endl;
	exit(0);
}

int	main(int argc, char* argv[]){
	struct sigaction sa;
	memset(&sa, 0, sizeof sa); 
	sa.sa_handler=&sigsegv_handler;
	sigaction(SIGSEGV, &sa, NULL); 
	cout<<"*******************************************************************************************"<<endl;
	cout<<"* ������� ������������� ���������� �������� �� ���� OpenGL. �����: ��������� �.�. 2007 �. *"<<endl;
	cout<<"*******************************************************************************************"<<endl;
	cout<<endl;
	if(argc>1){
		HGLWindowI* w=new HGLWindowI(argc, argv);
		w->filename=argv[1];
		window=w;
	}
	if(argc==1)
		window=new HGLWindowM(argc, argv);
	window->createWindow(640, 480);
	window->loop(); 
	return 0;
}



