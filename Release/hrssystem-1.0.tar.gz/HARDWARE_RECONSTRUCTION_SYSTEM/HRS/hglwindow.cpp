/***************************************************************************
 *   Copyright (C) 2007 by Hramchenko   *
 *   hramchenko@bk.ru   *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/
#include "hglwindow.h"

#include <iostream.h>

#include <GL/glut.h>

#include "hlogo.h"

HGLWindow*	HGLWindow::mainPointer=0;

HGLWindow::HGLWindow(int argc, char* argv[]){
	mainPointer=this;
	windowWidth=0;
	windowHeight=0;
	argc=argc;
	argv=argv;
	logo=new HLogo;
}

HGLWindow::~HGLWindow(){
	delete logo;
}

void	HGLWindow::createWindow(int width, int height){
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_RGBA | GLUT_DOUBLE | GLUT_DEPTH);
	glutInitWindowSize(width, height);
	glutInitWindowPosition((glutGet(GLUT_SCREEN_WIDTH)-width)/2,
													(glutGet(GLUT_SCREEN_HEIGHT)-height)/2);
	glutCreateWindow("������� ������������� ���������� �������� �� ���� OpenGL. �����: ��������� �.�. 2007 �. (HRS Reconstruction System)");
	glutReshapeFunc(reshapeCallback);
	glutDisplayFunc(displayCallback);
	glutKeyboardFunc(keyboardCallback);
	reshape(width, height);
	init();
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	logo->draw();
	glutSwapBuffers();
}

void	HGLWindow::loop(){
	glutMainLoop();
}

void	HGLWindow::drawLogo(){
	logo->draw();
}

void	HGLWindow::initCallback(){
	mainPointer->init();
}

void	HGLWindow::displayCallback(){
	mainPointer->display();
}

void	HGLWindow::reshapeCallback(int width, int height){
	mainPointer->windowWidth=width;
	mainPointer->windowHeight=height;
	mainPointer->reshape(width, height);
}

void	HGLWindow::keyboardCallback(unsigned char key, int x, int y){
	switch(key){
		case 27:
		case 'q':
		case 'Q':
			cout<<"���������� ���������."<<endl;
			exit(0);
			break;
	}
	mainPointer->keyboard(key, x, y);
}

