/***************************************************************************
 *   Copyright (C) 2007 by Hramchenko                                      *
 *   hramchenko@bk.ru                                                      *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 ***************************************************************************/
#include "hcomparator.h"

#include <string.h>
#include <cstdlib>

#include <GL/gl.h>
#include <GL/glu.h>
#include <GL/glext.h>

#include "hatipixelbuffer.h"
#include "hframe.h"
#include "hvoxel.h"

HComparator::HComparator(){
	HComparator(1024,1024);
}

HComparator::HComparator(int max_width, int max_height){
	pixelBuffer=new HATIPixelBuffer;
	pixelBuffer->make(max_width, max_height);
	initPixelBuffer();
	currentData=0;
	currentData=new char[max_width*max_height];
}

HComparator::~HComparator(){
	delete pixelBuffer;
	delete[] currentData;
}

char	HComparator::compare(HVoxel* voxel, HFrame* frame){
	if(!(voxel && frame))
		return -1;
	currentVoxel=voxel;
	currentFrame=frame;
	render();
	return compareData((char*)frame->data, currentData, frame->width*frame->height);
}

void	HComparator::initPixelBuffer(){
	pixelBuffer->begin();
	glDisable(GL_DEPTH_TEST);
	glDisable(GL_LIGHTING);
	glDisable(GL_BLEND);
	glEnable(GL_AUTO_NORMAL);
	glEnable(GL_VERTEX_ARRAY);
	glClearColor(1, 1, 1, 1);
	glColor3f(0, 0, 0);
	createVoxelList();
	pixelBuffer->end();
}

void	HComparator::createVoxelList(){
	static GLfloat vertices[]={
		0, 0, 0, 1, 0, 0,
		1, 1, 0, 0, 1, 0,
		0, 0, 1, 1, 0, 1,
		1, 1, 1, 0, 1, 1
	};
	static GLubyte indices[]={
		0, 3, 2, 1, 2, 3, 7, 6,
		0, 4, 7, 3, 1, 2, 6, 5,
		4, 5, 6, 7, 0, 1, 5, 4
	};
	voxelList=glGenLists(1);
	glVertexPointer(3, GL_FLOAT, 0, vertices);
	glMatrixMode(GL_MODELVIEW);
	glNewList(voxelList, GL_COMPILE);
	glPushMatrix();
	glTranslatef(0, -1, 0);	
	glDrawElements(GL_QUADS, 24, GL_UNSIGNED_BYTE, indices);
	glPopMatrix();
	glEndList();
}

inline void	HComparator::render(){
	pixelBuffer->begin();
	glLoadIdentity();
	glClear(GL_COLOR_BUFFER_BIT);
	currentFrame->setGL();
	glTranslatef(-0.5, -0.5, -0.5);
	glTranslatef(currentVoxel->x, currentVoxel->y, currentVoxel->z);
	glScalef(currentVoxel->size, currentVoxel->size, currentVoxel->size);
	glCallList(voxelList);
	glFlush();
	glReadPixels(0, 0, currentFrame->width, currentFrame->height, GL_RED, GL_UNSIGNED_BYTE, currentData);
	pixelBuffer->end();
}

inline char	HComparator::compareData(char* image, char* current_data, unsigned int data_length){
	unsigned int window_offset;
	unsigned int window_length;
	char new_value;
	char old_value;
	if(!findWindow(current_data, 0, data_length, window_offset, window_length))
		return 1;
	old_value=testWindow(image+window_offset, window_length);
	for(;;){
		if(!findWindow(current_data, window_offset+window_length, data_length, window_offset, window_length))
			return old_value;
		new_value=testWindow(image+window_offset, window_length);
		if(new_value!=old_value || old_value==2)
			return 2;
		old_value=new_value;
	}
}

inline bool	HComparator::findWindow(char* data_begin_abs, unsigned int data_begin_offset, unsigned int data_length, unsigned int& window_offset, unsigned int& window_length){
	if(data_begin_offset>=data_length)
		return false;
	char* data_begin=data_begin_abs+data_begin_offset;
	char*	data_end=data_begin_abs+data_length;
	window_offset=(unsigned int)memchr(data_begin, 0, (unsigned int)data_end-(unsigned int)data_begin);//-(unsigned int)data_begin;
	if(!window_offset)
		return false;
	window_length=(unsigned int)memchr((char*)window_offset, 255, (unsigned int)data_end-window_offset);
	if(!window_length)
		window_length=(unsigned int)data_end-(unsigned int)window_offset;
	else
		window_length=window_length-(unsigned int)window_offset;
	window_offset-=(unsigned int)data_begin_abs;
	return true;
}

inline char	HComparator::testWindow(char* data_begin, unsigned int data_length){
	bool is_white=(bool)memchr(data_begin, 255, data_length);
	bool is_black=(bool)memchr(data_begin, 0, data_length);
	if(is_white && is_black)
		return 2;
	if(is_white)
		return 0;
	return 1;
}


