/***************************************************************************
 *   Copyright (C) 2007 by Hramchenko                                      *
 *   hramchenko@bk.ru                                                      *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 ***************************************************************************/
#ifndef HATIPIXELBUFFER_H
#define HATIPIXELBUFFER_H

#include <GL/glx.h>

/**
	@author Hramchenko <user@localhost.localdomain>
*/

class HATIPixelBuffer{
	public:
    HATIPixelBuffer();
    ~HATIPixelBuffer();
		void	make(int width, int height);
		void	unlink();
		void	begin();
		void	end();
	private:
		Display*	display;
		Window	window;
		GLXPbuffer	pixelBuffer;
		GLXContext	windowContext;
		GLXContext	pixelBufferContext;
		bool	isCreated;
};

#endif
