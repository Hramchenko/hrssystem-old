/***************************************************************************
 *   Copyright (C) 2007 by Hramchenko   *
 *   hramchenko@bk.ru   *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/
#include "hvirtualtrackball.h"

#include <math.h>

#include <GL/gl.h>
#include <GL/glut.h>

HVirtualTrackball* HVirtualTrackball::mainPointer=0;

HVirtualTrackball::HVirtualTrackball(){
	mainPointer=this;
	winWidth=640;
	winHeight=480;
	angle=0;
	scale=1;
	translateX=0;
	translateY=0;
	lastPos[0]=lastPos[1]=lastPos[2]=0;
	trackingMouse=false;
	redrawContinue=false;
	trackballMove=false;
}

HVirtualTrackball::~HVirtualTrackball(){
}

void	HVirtualTrackball::initCallbacks(){
	glutMotionFunc(mouseMotion);
	glutMouseFunc(mouseButton);
	glutIdleFunc(idle);
}

void	HVirtualTrackball::applyTransform(){
	winWidth=glutGet(GLUT_WINDOW_WIDTH);
	winHeight=glutGet(GLUT_WINDOW_HEIGHT);
	glMatrixMode(GL_PROJECTION);
	glTranslatef(translateX, translateY, 0);
	translateX=translateY=0;
	glMatrixMode(GL_MODELVIEW);
	glScalef(scale, scale, scale);
	scale=1;
	if(trackballMove)
		glRotatef(angle, axis[0], axis[1], axis[2]);
}

void	HVirtualTrackball::mouseMotion(int x, int y){
	mainPointer->winWidth=glutGet(GLUT_WINDOW_WIDTH);
	mainPointer->winHeight=glutGet(GLUT_WINDOW_HEIGHT);
	float cur_pos[3];
	float	dx, dy, dz;
	calculateVector(x, y, mainPointer->winWidth, mainPointer->winHeight, cur_pos);
	if(mainPointer->trackingMouse){
		dx=cur_pos[0]-mainPointer->lastPos[0];
		dy=cur_pos[1]-mainPointer->lastPos[1];
		dz=cur_pos[2]-mainPointer->lastPos[2];
		if(dx || dy || dz){
			mainPointer->angle=90.0*sqrt(dx*dx+dy*dy+dz*dz);
			mainPointer->axis[0]=mainPointer->lastPos[1]*cur_pos[2]-mainPointer->lastPos[2]*cur_pos[1];
			mainPointer->axis[1]=mainPointer->lastPos[2]*cur_pos[0]-mainPointer->lastPos[0]*cur_pos[2];
			mainPointer->axis[2]=mainPointer->lastPos[0]*cur_pos[1]-mainPointer->lastPos[1]*cur_pos[0];
			mainPointer->lastPos[0]=cur_pos[0];
			mainPointer->lastPos[1]=cur_pos[1];
			mainPointer->lastPos[2]=cur_pos[2];
		}
	}
	glutPostRedisplay();
}

void	HVirtualTrackball::mouseButton(int button, int state, int x, int y){
	mainPointer->winHeight=glutGet(GLUT_WINDOW_HEIGHT);
	switch(button){
		case GLUT_LEFT_BUTTON:
			switch(state){
				case GLUT_DOWN:
					y=mainPointer->winHeight-y;
					mainPointer->startMotion(x, y);
					break;
				case GLUT_UP:
					mainPointer->stopMotion(x, y);
					break;
			}
			break;
		case GLUT_RIGHT_BUTTON:
			switch(state){
				case GLUT_DOWN:
					mainPointer->startX=x;
					mainPointer->startY=y;
					break;
				case GLUT_UP:
					mainPointer->translateX=(x-mainPointer->startX)*0.005;
					mainPointer->translateY=(mainPointer->startY-y)*0.005;
					mainPointer->redrawContinue=true;
					break;
			}	
			break;
		case GLUT_MIDDLE_BUTTON:
			switch(state){
				case GLUT_DOWN:
					mainPointer->startY=y;
					break;
				case GLUT_UP:
					mainPointer->scale=1+(y-mainPointer->startY)*0.005;
					mainPointer->redrawContinue=true;
					break;
			}
			break;
	}	
}

void	HVirtualTrackball::idle(){
	if(mainPointer->redrawContinue)
		glutPostRedisplay();
}

void	HVirtualTrackball::startMotion(int x, int y){
	mainPointer->winWidth=glutGet(GLUT_WINDOW_WIDTH);
	mainPointer->winHeight=glutGet(GLUT_WINDOW_HEIGHT);
	trackingMouse=true;
	redrawContinue=false;
	startX=x;
	startY=y;
	calculateVector(x, y, winWidth, winHeight, lastPos);
	trackballMove=true;
}

void	HVirtualTrackball::stopMotion(int x, int y){
	trackingMouse=false;
	if(startX!=x || startY!=y)
		redrawContinue=true;
	else{
		angle=0;
		redrawContinue=false;
	}
	trackballMove=false;
}

void	HVirtualTrackball::calculateVector(int x, int y, int width, int height, float* v){
	float d;
	float a;
	v[0]=(2.0*x-width)/width;
	v[1]=(height-2.0*y)/height;
	d=(float)sqrt(v[0]*v[0]+v[1]*v[1]);
	v[2]=cos((float)(M_PI/2.0)*((d<1.0)?d:1.0));
	a=1.0/(float)sqrt(v[0]*v[0]+v[1]*v[1]+v[2]*v[2]);
	v[0]*=a;
	v[1]*=a;
	v[2]*=a; 
}


