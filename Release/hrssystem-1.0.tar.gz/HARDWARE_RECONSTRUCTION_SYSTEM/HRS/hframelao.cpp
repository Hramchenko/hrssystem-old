/***************************************************************************
 *   Copyright (C) 2007 by Hramchenko                                      *
 *   hramchenko@bk.ru                                                      *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 ***************************************************************************/
#include "hframelao.h"

#include <iostream.h>
#include <math.h>

#include <GL/gl.h>
#include <GL/glu.h>

HFrameLAO::HFrameLAO(): HFrame(){
}

HFrameLAO::~HFrameLAO(){
}

#define	sqr(x) x*x 

void	HFrameLAO::setGL(){
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	glViewport(0,0,width,height);
	float r=sqrt(sqr(eyeX-centerX)+sqr(eyeY-centerY)+sqr(eyeZ-centerZ));
	if(width>height)
		glOrtho(-0.5*((float)height/(float)width), 0.5*((float)height/(float)width), -0.5*((float)height/(float)width), 0.5*((float)height/(float)width), -2, r+2);
	else
		glOrtho(-0.5*((float)width/(float)height), 0.5*((float)width/(float)height), -0.5*((float)width/(float)height), 0.5*((float)width/(float)height), -2, r+2);
	glMatrixMode(GL_MODELVIEW);
	gluLookAt(eyeX, eyeY, eyeZ, centerX, centerY, centerZ, upX, upY, upZ);
}

#undef sqr(x)

void	HFrameLAO::consoleInput(){
	cout<<"������� ��������� ��� gluLookAt(eyeX, eyeY, eyeZ, centerX, centerY, centerZ, upX, upY, upZ)"<<endl;
	cin>>eyeX>>eyeY>>eyeZ>>centerX>>centerY>>centerZ>>upX>>upY>>upZ;
}
