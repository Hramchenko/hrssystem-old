/***************************************************************************
 *   Copyright (C) 2007 by Hramchenko                                      *
 *   hramchenko@bk.ru                                                      *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 ***************************************************************************/
#ifndef HRECONSTRUCTION_H
#define HRECONSTRUCTION_H

/**
	@author Hramchenko <user@localhost.localdomain>
*/

#include <list>

class HFrame;
class	HVoxel;
class	HComparator;

class HReconstruction{
	public:
    HReconstruction();
    ~HReconstruction();
		void	prepare();
		void	start();
		void	clear();
		bool	idle();
		bool	isReconstructionComplited();
	public:
		std::list<HFrame*>	frames;
		HVoxel*	model;
		int	precision;
		int idleValue;
	private:
		void	process();
	private:
		friend 	void*	HReconstructionThreadFunction(void* params);
	private:
		int	currentPrecision;
		std::list<HVoxel*>*	currentVoxels;
		std::list<HVoxel*>*	nextVoxels;
		std::list<HVoxel*>::iterator	currentVoxel;
		std::list<HFrame*>::iterator	currentFrame;
		HComparator*	comparator;
		int	framesCount;
		int	currentFrameNumber;
		int	workFlag;
		bool	newReconstructionFlag;
};

#endif
