/***************************************************************************
 *   Copyright (C) 2007 by Hramchenko                                      *
 *   hramchenko@bk.ru                                                      *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 ***************************************************************************/
#include "hatipixelbuffer.h"

#include <GL/gl.h>
#include <GL/glx.h>
#define INT_PTR ptrdiff_t
//#include <GL/glATI.h>
#include <GL/glext.h>

HATIPixelBuffer::HATIPixelBuffer(){
	isCreated=false;
}

HATIPixelBuffer::~HATIPixelBuffer(){
	unlink();
}

void	HATIPixelBuffer::make(int width, int height){
	if(isCreated)
		unlink();
	display=glXGetCurrentDisplay();
	window=glXGetCurrentDrawable();
	windowContext=glXGetCurrentContext();
	int scrnum;
	GLXFBConfig* fbconfig;
	XVisualInfo* visinfo;
	int nitems;
	int attrib[]={
		GLX_DOUBLEBUFFER,  false,
		GLX_RED_SIZE,      1,
		GLX_GREEN_SIZE,    1,
		GLX_BLUE_SIZE,     1,
		GLX_DEPTH_SIZE,    1,
		GLX_RENDER_TYPE,   GLX_RGBA_BIT,
		GLX_DRAWABLE_TYPE, GLX_PBUFFER_BIT | GLX_WINDOW_BIT,
		None
	};
	int pbuf_attrib[]={
		GLX_PBUFFER_WIDTH,   width,
		GLX_PBUFFER_HEIGHT,  height,
		GLX_LARGEST_PBUFFER, False,
		None
	};
	scrnum=DefaultScreen(display);
	fbconfig=glXChooseFBConfig(display, scrnum, attrib, &nitems);
	pixelBuffer=glXCreatePbuffer(display, fbconfig[0], pbuf_attrib);
	visinfo = glXGetVisualFromFBConfig(display, fbconfig[0]);
	pixelBufferContext=glXCreateContext(display, visinfo, windowContext, GL_TRUE);
	XFree(fbconfig);
	XFree(visinfo);
	isCreated=true;
}

void	HATIPixelBuffer::unlink(){
	if(!isCreated)
		return;
	glXDestroyContext(display, pixelBufferContext);
	glXDestroyPbuffer(display, pixelBuffer);
	isCreated=false;
}

void	HATIPixelBuffer::begin(){
	if(!isCreated)
		return;
	window=glXGetCurrentDrawable();
	windowContext=glXGetCurrentContext();
	glXMakeCurrent(display, pixelBuffer, pixelBufferContext);
}

void	HATIPixelBuffer::end(){
	if(!isCreated)
		return;
	glXMakeCurrent(display, window, windowContext);
	window=0;
	windowContext=0;
}



