/***************************************************************************
 *   Copyright (C) 2007 by Hramchenko   *
 *   hramchenko@bk.ru   *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/
#include "hglwindowi.h"

#include <GL/gl.h>
#include <GL/glut.h>

#include "hframelao.h"

HGLWindowI::HGLWindowI(int argc, char* argv[]): HGLWindow(argc, argv){
}

HGLWindowI::~HGLWindowI(){
}

void	HGLWindowI::init(){
	glClearColor(0.0, 0.0, 0.0, 0.0);
	image=new HFrameLAO();
	image->loadData(filename); 
}

void 	HGLWindowI::display(){
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glDrawPixels(image->width, image->height, GL_GREEN, GL_UNSIGNED_BYTE, image->data);
	drawLogo();
	glutSwapBuffers();
}

void	HGLWindowI::reshape(int width, int height){
	glViewport(0, 0, width, height);
}

void	HGLWindowI::keyboard(unsigned char key, int x, int y){
}


