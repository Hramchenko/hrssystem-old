#!/bin/sh
cd ./HRS
make clean
cd ../TEXSDK
make clean
 
