#!/bin/sh
MYDIR=`pwd`
  
echo $MYDIR/TEST_DATA/HOME/1.png
echo 4
echo 0 0 2 0 0 0 0 1 2
echo 1
echo 1
echo $MYDIR/TEST_DATA/HOME/2.png
echo 4
echo 0 2 0 0 0 0 0 2 -2
echo 1
echo 0
echo

echo $MYDIR/TEST_DATA/HOME/0.png
echo 4
echo 2.26207 0  -1.06445 0 0 0 2.26207 1 -1.06445
echo 1
echo 1
echo $MYDIR/TEST_DATA/HOME/1.png
echo 4
echo 1.20438 0 2.19077 0 0 0 1.20438 1 2.19077
echo 1
echo 1
echo $MYDIR/TEST_DATA/HOME/2.png
echo 4
echo -2.11082 0 1.33957 0 0 0 -2.11082 1 1.33957
echo 1
echo 1
echo $MYDIR/TEST_DATA/HOME/3.png
echo 4
echo -1.46946 0 -2.02254 0 0 0 -1.46946 1 -2.02254
echo 1
echo 0
