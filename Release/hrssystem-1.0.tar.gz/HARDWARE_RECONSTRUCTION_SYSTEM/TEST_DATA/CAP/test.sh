#!/bin/sh
MYDIR=`pwd`
  
echo $MYDIR/TEST_DATA/CAP/1.png
echo 4
echo 0 0 2 0 0 0 0 1 2
echo 1
echo 1
echo $MYDIR/TEST_DATA/CAP/2.png
echo 4
echo 0 2 0 0 0 0 0 2 -2
echo 1
echo 0
echo