#!/bin/sh
 
 cd ./TEXSDK
 make && make install_devel
 
 cd ../HRS
make install
 
 
 
