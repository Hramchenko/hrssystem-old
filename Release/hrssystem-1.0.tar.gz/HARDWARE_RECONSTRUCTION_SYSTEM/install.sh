#!/bin/sh
 
 cd ./TEXSDK
 make && make install_devel
 
 cd ../HRS
make install
 
cd ../
`./TEST_DATA/CAP/test.sh | hrs`

 
 
