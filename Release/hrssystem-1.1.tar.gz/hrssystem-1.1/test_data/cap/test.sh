#!/bin/sh
MYDIR=`pwd`
  
echo $MYDIR/test_data/cap/1.png
echo 4
echo 0 0 2 0 0 0 0 1 2
echo 1
echo 1
echo $MYDIR/test_data/cap/2.png
echo 4
echo 0 2 0 0 0 0 0 2 -2
echo 1
echo 0
echo