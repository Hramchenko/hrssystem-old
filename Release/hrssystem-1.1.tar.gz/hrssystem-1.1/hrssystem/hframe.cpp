/***************************************************************************
 *   Copyright (C) 2007 by Hramchenko                                      *
 *   hramchenko@bk.ru                                                      *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 ***************************************************************************/
#include "hframe.h"

#include <TEXSDK/libTexture.h>
#include <TEXSDK/Texture.h>

#include <iostream.h>

#include <GL/gl.h>

HFrame::HFrame(){
	data=0;
	width=height=0;
}

HFrame::HFrame(const HFrame& rhs){
	data=rhs.data;
	width=rhs.width;
	height=rhs.height;
}

HFrame::~HFrame(){
	delete[] data;
}

void	HFrame::loadData(const char* filename){
	Texture* texture=getTexture(filename);
	width=texture->getWidth();
	height=texture->getHeight();
	unsigned char* src_data=(unsigned char*)texture->getData();
	unsigned char* new_data=new unsigned char[width*height];
	int i,j;
	switch(texture->getFormat()){
		case GL_BGRA:
		case GL_RGBA:
			for(j=0; j<height; j++)
				for(i=0; i<width; i++)
					new_data[i+j*width]=255-src_data[(i+(width*height-1-j*width))*4+3]; 
			break;
		case GL_BGR:
		case GL_RGB:
			for(i=0; i<width*height; i++)
				new_data[i]=src_data[i*3]; 
			break;
		case GL_RGB8:
			for(i=0; i<width*height; i++)
				new_data[i]=src_data[i]; 
			break;
		default:
			cerr<<"Error! Unknown format: #"<<texture->getFormat()<<"."<<endl;
			break;
	}
	delete texture;
	data=new_data;
	// ��������� �����������
	for(i=0; i<width*height; i++){
		if(data[i]<127)
			data[i]=0;
		else
			data[i]=255;
	}
}
