/***************************************************************************
 *   Copyright (C) 2007 by Hramchenko   *
 *   hramchenko@bk.ru   *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/
#include "hglwindowm.h"

#include <iostream.h>

#include <GL/gl.h>
#include <GL/glu.h>
#include <GL/glut.h>

#include "hvoxel.h"
#include "hmodelviewerc.h"
#include "hframe.h"
#include "hframelo.h"
#include "hframelp.h"
#include "hframemp.h"
#include "hframelao.h"
#include "hcomparator.h"
#include "hreconstruction.h"
#include "hvirtualtrackball.h"

HGLWindowM::HGLWindowM(int argc, char* argv[]): HGLWindow(argc, argv){
	stop=false;
	root=new HVoxel;
	virtualTrackball=new HVirtualTrackball;
}

HGLWindowM::~HGLWindowM(){
	delete root;
	delete virtualTrackball;
	delete reconstruction;
	delete modelViewer;
}

void	HGLWindowM::init(){
	glEnable(GL_DEPTH_TEST);
	glEnable(GL_FOG);
	glEnable(GL_BLEND);
	glEnable(GL_COLOR_MATERIAL);
	glShadeModel(GL_SMOOTH);
	glDepthFunc(GL_LEQUAL);
	glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);
	glHint(GL_POLYGON_SMOOTH_HINT, GL_NICEST );
	GLfloat material_emission[]={0.5, 0.5, 1.0, 1.0};
	glMaterialfv(GL_FRONT_AND_BACK, GL_EMISSION, material_emission);
	glClearColor(0.0, 0.0, 0.0, 0.0);
	virtualTrackball->initCallbacks();
	reconstruction=new HReconstruction;
	modelViewer=new HModelViewerC;
	loadFrames();
	reconstruction->model=root;
	reconstruction->precision=1;
	reconstruction->idleValue=20;
	reconstruction->prepare();
}

void 	HGLWindowM::display(){
	if(!stop)
		reconstruction->idle();
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	virtualTrackball->applyTransform();
	modelViewer->prepare(root);
	glPushMatrix();
	glColor4f(0.5, 0.5, 1.0, 1.0);
	glRotatef(90, 0, 1, 0);
	glTranslatef(-0.5, -0.5, -0.5);
	modelViewer->view(); 
	glPopMatrix();
	drawLogo();
	glutSwapBuffers();
}

void	HGLWindowM::reshape(int width, int height){
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	glViewport(0, 0, width, height);
	gluPerspective(20.0, (float)width/(float)height, 0.5, 10.0);
	gluLookAt(4.0, 0.0, 4.0, 0.0, 0.0, 0.0, 4.0, 4.0, 4.0);
	glMatrixMode(GL_MODELVIEW);
}
		
void	HGLWindowM::keyboard(unsigned char key, int x, int y){
	switch (key){
		case 'p':
		case 'P':
			stop=!stop;
			break;
		case '=':
		case '+':
			reconstruction->start();
			glutPostRedisplay();
			break;
	}
}

void	HGLWindowM::loadFrames(){
	HFrame* frame=0;
	char filename[1000];
	int flg=1;
	int apply_flg=1;
	int i;
	unsigned int frame_type;
	cout<<"Please give some photos with object to program, ";
	cout<<"and specify projection matrix. ";
	cout<<"Now you can do this."<<endl; 
	for(i=0; flg;){
		cout<<endl;
		cout<<"Frame #"<<i<<endl;
		cout<<"Please enter full path to image: "<<endl;
		if(cin.peek()==10)
			cin.ignore(1, '\n');
		cin.get(filename,1000);
		cin.ignore(1, '\n');
		cout<<"How do you want to define a projection matrix?"<<endl;
		cout<<"If you want to define matrix with glOrtho and gluLookAt type '1'."<<endl;
		cout<<"If you want to define matrix with gluPerspective and gluLookAt type '2'."<<endl;
		cout<<"If you want to define projection matrix directly type '3'."<<endl;
		cout<<"If you want to define matrix with gluLookAt and default ortho matrix type '4'."<<endl;
		cin>>frame_type;
		switch(frame_type){
			case 1:
				frame=new HFrameLO;
				break;
			case 2:
				frame=new HFrameLP;
				break;
			case 3:
				frame=new HFrameMP;
				break;
			case 4:
				frame=new HFrameLAO;
				break;
		}
		frame->consoleInput();
		cout<<"Are parameters entered correctly? 1/0"<<endl;
		cin>>apply_flg;
		if(apply_flg){
			frame->loadData(filename);
			reconstruction->frames.push_back(frame);
			i++;
		}
		else
			delete frame;
		cout<<"Do you want to add next frame? 1/0"<<endl;
		cin>>flg;
	}
	cout<<"Enter complete."<<endl;
	cout<<endl;
	cout<<"Now program reconstruct a model.";
	cout<<endl;
	cout<<"Current precision 1. If you want to increase precision press '+'."<<endl;
	cout<<"If you want to start/stop reconstruction press 'P'."<<endl;
	cout<<endl;
	cout<<"If you want to rotate a model press a left mouse button and move a cursor."<<endl;
	cout<<"If you want to move a model press a right mouse button and move a cursor."<<endl;
	cout<<"If you want to scale a model press a middle mouse button and move a cursor."<<endl;
	cout<<endl;
	cout<<"If you want to quit press 'Q' or 'Esc'."<<endl;
	cout<<endl;
}
