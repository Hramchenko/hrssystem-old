/***************************************************************************
 *   Copyright (C) 2007 by Hramchenko                                      *
 *   hramchenko@bk.ru                                                      *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 ***************************************************************************/
#include "hreconstruction.h"

#include "hframe.h"
#include "hvoxel.h"
#include "hcomparator.h"

HReconstruction::HReconstruction(){
	workFlag=0;
	precision=1;
	idleValue=5;
	framesCount=0;
	currentPrecision=0;
	currentFrameNumber=0;
	newReconstructionFlag=1;
	currentVoxels=new std::list<HVoxel*>;
	nextVoxels=new std::list<HVoxel*>;
}

HReconstruction::~HReconstruction(){
	delete currentVoxels;
	delete nextVoxels;
	delete comparator;
}

void	HReconstruction::prepare(){
	if(!newReconstructionFlag)
		return;
	int width=0;
	int height=0;
	framesCount=0;
	for(currentFrame=frames.begin(); currentFrame!=frames.end(); currentFrame++){
		if((*currentFrame)->width>width)
			width=(*currentFrame)->width;
		if((*currentFrame)->height>height)
			height=(*currentFrame)->height;
		framesCount++;
	}
	currentFrame=frames.begin();
	currentVoxels->push_back(model);
	currentVoxel=currentVoxels->begin();
	comparator=new HComparator(width, height);
	newReconstructionFlag=0;
	workFlag=1;
}

void	HReconstruction::start(){
	workFlag=1;
}

void	HReconstruction::clear(){
	currentPrecision=0;
	currentVoxels->clear();
	nextVoxels->clear();
	newReconstructionFlag=1;
	workFlag=0;
	delete comparator;
}

bool	HReconstruction::isReconstructionComplited(){
	return !workFlag;
}

bool	HReconstruction::idle(){
	if(!workFlag)
		return false;
	process();
	return true;
}

void	HReconstruction::process(){
	int k=0;
	std::list<HVoxel*>* temp;
	workFlag=1;
	for(int i=currentPrecision; i<precision; i++){
		for(; currentVoxel!=currentVoxels->end(); ++currentVoxel, currentPrecision=i){
			char t;
			for(; currentFrame!=frames.end(); ++currentFrame, currentFrameNumber++){
				t=comparator->compare(*currentVoxel, *currentFrame);
				switch(t){
					case 0:
						(*currentVoxel)->type=0;
						goto label;
						break;
					case 2:
						(*currentVoxel)->type=2;
				}
			}
			if((*currentVoxel)->type==2){
				(*currentVoxel)->createSubvoxels();
				int j;
				for(j=0; j<8; j++)
					nextVoxels->push_back(&((*currentVoxel)->subvoxels[j]));
			}
			label:
			currentFrame=frames.begin();
			currentFrameNumber=0;
			if((k++>idleValue)&&(currentFrameNumber+1<framesCount))
				return;
		}
		temp=currentVoxels;
		temp->clear();
		currentVoxels=nextVoxels;
		nextVoxels=temp;
		currentVoxel=currentVoxels->begin();
		currentPrecision=i;
	}
	workFlag=0;
}
