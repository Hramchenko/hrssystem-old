/***************************************************************************
 *   Copyright (C) 2007 by Hramchenko                                      *
 *   hramchenko@bk.ru                                                      *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 ***************************************************************************/
#include "hframemp.h"

#include <iostream.h>

#include <GL/gl.h>

HFrameMP::HFrameMP(): HFrame(){
	projectionMatrix=new float[16];
}

HFrameMP::~HFrameMP(){
	delete[] projectionMatrix;
}

void	HFrameMP::setGL(){
	glMatrixMode(GL_PROJECTION);
	glViewport(0, 0, width, height);
	glLoadMatrixf(projectionMatrix);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
}

void	HFrameMP::consoleInput(){
	cout<<"Enter GL_PROJECTION matrix:"<<endl;
	for(int i=0; i<15; i++, cin>>projectionMatrix[i]);
}


