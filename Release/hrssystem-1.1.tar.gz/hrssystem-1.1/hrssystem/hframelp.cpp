/***************************************************************************
 *   Copyright (C) 2007 by Hramchenko                                      *
 *   hramchenko@bk.ru                                                      *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 ***************************************************************************/
#include "hframelp.h"

#include <iostream.h>

#include <GL/gl.h>
#include <GL/glu.h>

HFrameLP::HFrameLP(): HFrame(){
}

HFrameLP::~HFrameLP(){
}

void	HFrameLP::setGL(){
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	glViewport(0, 0, width, height);
	gluPerspective(fovy, width/height, near, far);
	glMatrixMode(GL_MODELVIEW);
	gluLookAt(eyeX, eyeY, eyeZ, centerX, centerY, centerZ, upX, upY, upZ);
}

void	HFrameLP::consoleInput(){
	cout<<"Enter parameters for gluLookAt(eyeX, eyeY, eyeZ, centerX, centerY, centerZ, upX, upY, upZ)"<<endl;
	cin>>eyeX>>eyeY>>eyeZ>>centerX>>centerY>>centerZ>>upX>>upY>>upZ;
	cout<<"Enter parameters for gluPerspective(fovy, near, far)"<<endl;
	cin>>fovy>>near>>far;
}
