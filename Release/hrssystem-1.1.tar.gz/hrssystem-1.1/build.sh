#!/bin/sh
 
cd ./TEXSDK
make -j5
 
cd ../hrssystem
make -j5  
cd ../
`./test_data/cap/test.sh | ./hrssystem/hrssystem`