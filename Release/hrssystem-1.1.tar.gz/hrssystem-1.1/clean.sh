#!/bin/sh
cd ./hrssystem
make clean
cd ../TEXSDK
make clean
 
